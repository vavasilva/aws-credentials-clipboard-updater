# AWS Credentials Clipboard Updater
from .cli import main

__all__ = ['main']