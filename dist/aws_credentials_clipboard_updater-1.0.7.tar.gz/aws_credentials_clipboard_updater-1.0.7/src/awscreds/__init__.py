# AWS Credentials Clipboard Updater
from .cli import main, update, delete, list

__all__ = ['main', 'update', 'delete', 'list']